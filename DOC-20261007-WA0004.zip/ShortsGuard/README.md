# Shorts Guard — Session/Cooldown edition

Android AccessibilityService that detects YouTube Shorts and runs a repeating session cycle:

1. Shorts are allowed for the configured **usage time** (default 30 minutes).
2. A configurable **warning/grace period** begins (default 2 minutes).
3. At the end of the grace period, Shorts are blocked and a configurable **cooldown** begins (default 60 minutes).
4. After cooldown, the session automatically resets and Shorts are available again.
5. Normal/long-form YouTube videos are not counted or blocked.

## Build
Open the `ShortsGuard` folder in Android Studio, sync Gradle, then Build > Build APK(s).

## Enable
Install the APK, open Shorts Guard, set the three timers, save, then enable the Accessibility Service in Android Settings > Accessibility > Shorts Guard.

## Important limitation
YouTube does not provide a public API to third-party apps that says whether the current screen is a Short. Detection is therefore based on Accessibility UI signals and can break if YouTube changes its UI.
