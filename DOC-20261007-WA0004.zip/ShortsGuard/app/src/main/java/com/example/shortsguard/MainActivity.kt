package com.example.shortsguard

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("guard", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val usage = findViewById<EditText>(R.id.usageInput)
        val warning = findViewById<EditText>(R.id.warningInput)
        val cooldown = findViewById<EditText>(R.id.cooldownInput)
        val status = findViewById<TextView>(R.id.statusText)
        val save = findViewById<Button>(R.id.saveButton)
        val access = findViewById<Button>(R.id.accessButton)

        usage.setText(prefs.getInt("usageMinutes", 30).toString())
        warning.setText(prefs.getInt("warningMinutes", 2).toString())
        cooldown.setText(prefs.getInt("cooldownMinutes", 60).toString())

        fun refresh() {
            val state = prefs.getString("state", "READY")
            status.text = when (state) {
                "COOLDOWN" -> "Status: Shorts cooldown active"
                "WARNING" -> "Status: Warning / grace period"
                else -> "Status: Ready for a new Shorts session"
            }
        }
        refresh()

        save.setOnClickListener {
            val u = usage.text.toString().toIntOrNull()?.coerceIn(1, 1440) ?: 30
            val w = warning.text.toString().toIntOrNull()?.coerceIn(1, 60) ?: 2
            val c = cooldown.text.toString().toIntOrNull()?.coerceIn(1, 1440) ?: 60
            prefs.edit().putInt("usageMinutes", u).putInt("warningMinutes", w).putInt("cooldownMinutes", c).apply()
            refresh()
        }

        access.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
    }

    override fun onResume() {
        super.onResume()
        findViewById<TextView>(R.id.statusText)?.let {
            it.text = when (prefs.getString("state", "READY")) {
                "COOLDOWN" -> "Status: Shorts cooldown active"
                "WARNING" -> "Status: Warning / grace period"
                else -> "Status: Ready for a new Shorts session"
            }
        }
    }
}
