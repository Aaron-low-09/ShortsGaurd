package com.example.shortsguard

import android.accessibilityservice.AccessibilityService
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.max

class ShortsAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("guard", MODE_PRIVATE) }
    private var shortsDetected = false
    private var overlay: View? = null
    private var lastTick = SystemClock.elapsedRealtime()

    private val tick = object : Runnable {
        override fun run() {
            val now = SystemClock.elapsedRealtime()
            val delta = ((now - lastTick) / 1000L).coerceIn(0L, 5L)
            lastTick = now

            val state = prefs.getString("state", "READY") ?: "READY"
            when (state) {
                "READY", "WARNING" -> {
                    if (shortsDetected) {
                        val used = prefs.getLong("sessionUsed", 0L) + delta
                        val limit = prefs.getInt("usageMinutes", 30) * 60L
                        val warning = prefs.getInt("warningMinutes", 2) * 60L
                        prefs.edit().putLong("sessionUsed", used).apply()

                        if (used >= limit + warning) {
                            startCooldown()
                        } else if (used >= limit) {
                            if (state != "WARNING") {
                                prefs.edit().putString("state", "WARNING").apply()
                                showWarningOverlay(limit + warning - used)
                            } else {
                                updateWarningOverlay(limit + warning - used)
                            }
                        }
                    }
                }
                "COOLDOWN" -> {
                    val ends = prefs.getLong("cooldownEndsAt", 0L)
                    if (now >= ends) {
                        prefs.edit().putString("state", "READY")
                            .putLong("sessionUsed", 0L)
                            .putLong("cooldownEndsAt", 0L)
                            .apply()
                        removeOverlay()
                    } else if (shortsDetected) {
                        showCooldownOverlay(ends - now)
                    }
                }
            }

            handler.postDelayed(this, 1000L)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        lastTick = SystemClock.elapsedRealtime()
        recoverState()
        handler.post(tick)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (event.packageName?.toString() != "com.google.android.youtube") {
            shortsDetected = false
            removeOverlay()
            return
        }

        val root = rootInActiveWindow ?: run {
            shortsDetected = false
            return
        }
        shortsDetected = looksLikeShorts(root)

        if (!shortsDetected) {
            // Long-form videos and other YouTube screens are never counted/blocked.
            removeOverlay()
            return
        }

        when (prefs.getString("state", "READY")) {
            "COOLDOWN" -> {
                val ends = prefs.getLong("cooldownEndsAt", 0L)
                if (SystemClock.elapsedRealtime() < ends) showCooldownOverlay(ends - SystemClock.elapsedRealtime())
            }
            "WARNING" -> showWarningOverlay(remainingWarningMillis())
        }
    }

    override fun onInterrupt() { shortsDetected = false }

    private fun looksLikeShorts(root: AccessibilityNodeInfo): Boolean {
        val texts = ArrayList<String>()
        collectText(root, texts, 0)
        val all = texts.joinToString(" ").lowercase()
        val hasShorts = all.contains("shorts")
        val hasShare = all.contains("share")
        val hasComments = all.contains("comment") || all.contains("comments")
        val hasSubscribe = all.contains("subscribe")
        return hasShorts && (hasShare || hasComments) && hasSubscribe
    }

    private fun collectText(node: AccessibilityNodeInfo, out: MutableList<String>, depth: Int) {
        if (depth > 28) return
        node.text?.toString()?.takeIf { it.isNotBlank() }?.let(out::add)
        node.contentDescription?.toString()?.takeIf { it.isNotBlank() }?.let(out::add)
        for (i in 0 until node.childCount) node.getChild(i)?.let { collectText(it, out, depth + 1) }
    }

    private fun recoverState() {
        if (prefs.getString("state", "READY") == "COOLDOWN") {
            if (SystemClock.elapsedRealtime() >= prefs.getLong("cooldownEndsAt", 0L)) {
                prefs.edit().putString("state", "READY").putLong("sessionUsed", 0L).putLong("cooldownEndsAt", 0L).apply()
            }
        }
    }

    private fun remainingWarningMillis(): Long {
        val limit = prefs.getInt("usageMinutes", 30) * 60_000L
        val warning = prefs.getInt("warningMinutes", 2) * 60_000L
        val used = prefs.getLong("sessionUsed", 0L) * 1000L
        return max(0L, limit + warning - used)
    }

    private fun startCooldown() {
        val cooldownMs = prefs.getInt("cooldownMinutes", 60) * 60_000L
        prefs.edit().putString("state", "COOLDOWN")
            .putLong("cooldownEndsAt", SystemClock.elapsedRealtime() + cooldownMs)
            .apply()
        showCooldownOverlay(cooldownMs)
        // Leave the Shorts player immediately. The overlay also prevents immediate re-entry.
        performGlobalAction(GLOBAL_ACTION_BACK)
        Toast.makeText(this, "Shorts locked — cooldown started", Toast.LENGTH_LONG).show()
    }

    private fun showWarningOverlay(remainingMs: Long) {
        if (overlay == null) {
            overlay = buildOverlay(
                "Shorts warning",
                "Your Shorts session has reached its limit. Close Shorts before the grace period ends.\n\nTime left: ${format(remainingMs)}",
                "Close Shorts"
            ) { performGlobalAction(GLOBAL_ACTION_BACK); removeOverlay() }
            addOverlay(overlay!!)
        } else updateWarningOverlay(remainingMs)
    }

    private fun updateWarningOverlay(remainingMs: Long) {
        val box = overlay as? LinearLayout ?: return
        (box.getChildAt(1) as? TextView)?.text = "Your Shorts session has reached its limit. Close Shorts before the grace period ends.\n\nTime left: ${format(remainingMs)}"
    }

    private fun showCooldownOverlay(remainingMs: Long) {
        if (overlay == null) {
            overlay = buildOverlay(
                "Shorts locked",
                "Your Shorts session is over. Shorts will be available again in ${format(remainingMs)}.\n\nLong-form YouTube videos are not affected.",
                "Go back"
            ) { performGlobalAction(GLOBAL_ACTION_BACK) }
            addOverlay(overlay!!)
        } else {
            val box = overlay as? LinearLayout ?: return
            (box.getChildAt(1) as? TextView)?.text = "Your Shorts session is over. Shorts will be available again in ${format(remainingMs)}.\n\nLong-form YouTube videos are not affected."
        }
    }

    private fun buildOverlay(titleText: String, messageText: String, buttonText: String, action: () -> Unit): View {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 40, 48, 40)
            setBackgroundColor(Color.WHITE)
            elevation = 20f
            addView(TextView(this@ShortsAccessibilityService).apply {
                text = titleText; textSize = 24f; setTextColor(Color.BLACK)
            })
            addView(TextView(this@ShortsAccessibilityService).apply {
                text = messageText; textSize = 17f; setTextColor(Color.DKGRAY); setPadding(0, 20, 0, 20)
            })
            addView(Button(this@ShortsAccessibilityService).apply {
                text = buttonText; setOnClickListener { action() }
            })
        }
    }

    private fun addOverlay(view: View) {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        wm.addView(view, WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER })
    }

    private fun removeOverlay() {
        overlay?.let {
            try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } catch (_: Exception) {}
        }
        overlay = null
    }

    private fun format(ms: Long): String {
        val totalSeconds = max(0L, ms / 1000L)
        return "%02d:%02d".format(totalSeconds / 60L, totalSeconds % 60L)
    }
}
